# Changelog
- 03/03/19
```
- เพิ่มnotebook สำรวจนามสกุล/ตระกูลที่มีผู้สมัครส.ส.มากกว่าหนึ่งคนขึ้นไป
```
- 25/02/19
```
- ย้ายลิงค์ฟอร์มแจ้ง
- แก้โลโก้ พรรค เพื่อชาติ
```
- 22/02/19
```
- รหัสที่มีปัญหา 33150, 41000, 12120
- https://www.facebook.com/electinth/posts/371876360297770?comment_id=372263686925704&comment_tracking=%7B%22tn%22%3A%22R9%22%7D
- เพิ่ม logo พรรค
```
- 17/02/19
```
# v0.2.1
- search popup
- correct อนาคตใหม่ ดาต้า (กทม.​ 12, 30)
- update หมายเหตุ

# v0.2
- Attach index url to the ELECT logo (Issue#1)
- Use React Prod files (PR#2)
- Track candidate search to Google Analytics.
- Correct อนาคตไทย candidates, not อนาคตใหม่
- logo พรรคกลาง
```